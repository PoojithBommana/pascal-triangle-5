num = int(input())
# reading the input
if num <= 5 :
    for i in range(num):
        
    # adjust space
        print(' '*(num-i), end='')
        
    # compute power of 11
        print(' '.join(map(str, str(11**i))))
        
if num > 5 :
    for i in range(num):  
        for j in range(num - i):
            print(" " , end = "")
              # taking then spaces 
        coef = 1    
          # as pascal starts with 1 so coef = 1 
        for j in range(i+1):
            print(coef , end = " ")
              # as coef update the values in it
            coef = coef * (i-j) // (j+1)
             # formula for the pascal triangle
        print()